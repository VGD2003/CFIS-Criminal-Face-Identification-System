Click on star :star: and fork this repository to your system.

# 1. Start page:

![1](https://user-images.githubusercontent.com/25504941/91967318-b3dc6500-ed30-11ea-9131-d5c7b0adc05f.PNG)

# 2. Register a Criminal

![2](https://user-images.githubusercontent.com/25504941/91967325-b6d75580-ed30-11ea-9a23-c305decb352c.PNG)

# 3. Detect Multiple persons from photo

![3](https://user-images.githubusercontent.com/25504941/91967341-b9d24600-ed30-11ea-96bc-a5f8ccfb2497.PNG)

# 4. Details of criminal

![4](https://user-images.githubusercontent.com/25504941/91967352-bc34a000-ed30-11ea-8b0b-cb11d062af91.PNG)

# 5. Detect criminal from photo

![6](https://user-images.githubusercontent.com/25504941/91967357-bccd3680-ed30-11ea-9801-5a211009f7a7.PNG)

# 6. Detect criminals from video surviellance

![9](https://user-images.githubusercontent.com/25504941/91967366-be96fa00-ed30-11ea-9881-173bf883bbd4.png)
